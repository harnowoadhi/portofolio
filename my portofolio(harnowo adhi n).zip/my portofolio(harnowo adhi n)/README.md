# PEMWEB-Portofolio-Sederhana
Web adalah sebuah penyebaran informasi melalui internet. Sebenarnya antara www (world wide web) dan web adalah sama karena kebanyakan orang menyingkat www menjadi web saja. Web merupakan hal yang tidak dapat dipisahkan dari dunia internet.

# HTML
HTML adalah singkatan dari Hypertext Markup Language yang memiliki pengertian bahasa markup standar untuk membuat dan menyusun halaman pada aplikasi website. Jika kamu sedang mengembangkan website, kamu bisa menggunakan HTML atau bahasa markup ini untuk membuat paragraf, heading, maupun link pada suatu web page.

# CSS
CSS adalah singkatan dari cascading style sheets, yaitu bahasa yang digunakan untuk menentukan tampilan dan format halaman website. Dengan CSS, Anda bisa mengatur jenis font, warna tulisan, dan latar belakang halaman.CSS digunakan bersama dengan bahasa markup, seperti HTML dan XML untuk membangun sebuah website yang menarik dan memiliki fungsi yang berjalan baik. CSS juga berguna untuk mengatasi keterbatasan HTML dalam mengatur format halaman website. Kenapa demikian? Apabila hanya menggunakan HTML ketika membangun website dengan beberapa halaman, Anda harus menulis tag untuk sebuah elemen HTML di semua halaman tersebut.  Dengan adanya CSS, Anda cukup menulis kode satu kali untuk sebuah elemen HTML untuk diterapkan ke semua halaman. Nantinya, ketika akan melakukan perubahan, Anda juga cukup melakukan perubahan pada satu kode tadi.

